import React, {useCallback} from 'react'
import { StyleSheet, Text, View, Image, Button, ScrollView, Alert } from 'react-native'
import { HeaderButtons, Item } from 'react-navigation-header-buttons'
import { useDispatch, useSelector } from 'react-redux'
import { THEME } from '../theme'
import { AppHeaderIcon } from '../components/AppHeaderIcon'
import { removePost, toggleBooked } from '../store/actions/post'


export const PostScreen = ({navigation, route}) => {
  const dispatch = useDispatch()
  
  const postId = route.params?.postId ?? null
  const date = route.params?.date

  
  const post = useSelector(state => state.post.allPosts.find(p => p.id === postId))

  const toggleHandler = useCallback(() => {
    dispatch(toggleBooked(post))
  }, [dispatch, post])
 
  const removeHandler = () => {
    Alert.alert(
      "Удаление поста",
      "Вы уверены?",
      [
        {
          text: "Отменить",
          style: "cancel"
        },
        { text: "Удалить", style: 'destructive', 
        onPress() {
          navigation.navigate('MainScreen')
          dispatch(removePost(postId))
        } }
      ],
      {
        cancelable: false,
      }
    )
  }
  const toggleHandlerItem = route.params?.toggleHandler
  
  const booked = useSelector(state => state.post.bookedPosts.some(post => post.id === postId))

  React.useLayoutEffect(() => {
    
    const iconName = booked ? 'ios-star' : 'ios-star-outline'
    
    navigation.setOptions({ booked })
    navigation.setOptions({ toggleHandler })

    navigation.setOptions({
      title: 'Пост от ' + new Date(date).toLocaleDateString(),
      headerRight: () => (
        <HeaderButtons HeaderButtonComponent={AppHeaderIcon}>
          <Item 
            title='Сделать фото' 
            iconName={iconName} 
            onPress={toggleHandler}/>
        </HeaderButtons>
      ),
    });
  }, [navigation, date, toggleHandler, booked])

  if(!post) {
    return null
  }
    return (
       <ScrollView>
           <Image source={{uri: post.img}} style={styles.image}/>
           <View style={styles.textWrap}>
             <Text style={styles.title}>
               {post.text}
             </Text>
             <Button title='Удалить' color={THEME.RED_COLOR} onPress={removeHandler}/>
           </View>
       </ScrollView> 
    )
}



const styles = StyleSheet.create({
    textWrap: {
      padding: 10,
    },
    image: {
      width: '100%',
      height: 200
    },
    title: {
      fontFamily: 'open-regular'
    }
})
  