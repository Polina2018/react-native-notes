import React, {useState, useRef, useEffect} from 'react'
import { StyleSheet, Text, View, TextInput, Image, Button, ScrollView, TouchableWithoutFeedback, Keyboard } from 'react-native'
import { useDispatch } from 'react-redux'
import { addPost } from '../store/actions/post'
import { THEME } from '../theme'
import { PhotoPicker } from '../components/PhotoPicker'

export const CreateScreen = ({navigation}) => {
  const dispatch = useDispatch()
  const [text, setText] = useState('')
  const [imgRef, setImgRef] = useState('')
  //const imgRef = useRef()

  const photoPickHandler = uri => {
    let img = {
      setImgRef: uri
    }
    setImgRef(img.setImgRef)
  }
  const saveHandler = () => {
    const post = {
      date: new Date().toJSON(),
      text: text,
      img: imgRef,
      booked: false
    }
   
    dispatch(addPost(post))
    navigation.navigate('MainScreen')
    setText(null)
    setImgRef(null)
     //imgRef.current = null
  }
  console.log('imgRef', setText)

    return (
      <ScrollView>
        <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
          <View style={styles.wrapper}>
              <Text style={styles.title}>Создай новый пост</Text>
              <TextInput 
                style={styles.textarea}
                placeholder='Введите текст заметки'
                value={text}
                onChangeText={setText}
                multiline
              />
              <PhotoPicker onPick={photoPickHandler}/>
              <Button 
                title='Создать пост' 
                color={THEME.MAIN_COLOR} 
                onPress={saveHandler}
                disabled={!text}
              />
          </View> 
       </TouchableWithoutFeedback>
      </ScrollView>
    )
}



const styles = StyleSheet.create({
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },
    wrapper: {
      padding: 15,
    },
    title: {
      fontSize: 20,
      textAlign: 'center',
      marginVertical: 10,
      fontFamily: 'open-regular'
    },
    textarea: {
      padding: 10,
      marginBottom: 10
    }
})
  