export const THEME = {
    RED_COLOR: '#d81b60',
    GREY_COLOR: '#757575',
    MAIN_COLOR: '#303f9f',
    PADDING_HORIZONTAL: 30,
}